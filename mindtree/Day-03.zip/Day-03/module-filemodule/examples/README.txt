This module is to just create files in different ways.

How to use this module:
# Without passing any variable
include filemodule

# With passing variable value
class {'filemodule':
  $ensure_value => 'present'
}