echo "My name is: `whoami`"
date
